// This is your test publishable API key.
const stripeOnramp = StripeOnramp("pk_test_51TTHmmQZx3micfpjEpLIePluJ12BMCw4YApBxTkRuJDsxHot9AI7Xq2rplHydMVIyYijEMPBGnTZsiyItwjwpmHj004iZmr3Dw");

let session;

initialize();

async function initialize() {
  // Fetches an onramp session and captures the client secret
  const response = await fetch(
    "/create-onramp-session",
    {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      transaction_details: {
        destination_currency: "usdc",
        destination_exchange_amount: "13.37",
        destination_network: "ethereum",
      }
     }),
  });
  const { clientSecret } = await response.json();

  session = stripeOnramp
    .createSession({
      clientSecret,
      appearance: {
        theme: "dark",
      }
    })
    .addEventListener('onramp_session_updated', (e) => {
      showMessage(`OnrampSession is now in ${e.payload.session.status} state.`)
    })
    .mount("#onramp-element");
}

// ------- UI helpers -------

function showMessage(messageText) {
  const messageContainer = document.querySelector("#onramp-message");

  messageContainer.textContent = messageText;
}