# Integrate with Stripe onramp

Build a simple page to use Stripe onramp. Included are some basic
build and run scripts you can use to start up the application.

## Running the sample

1. Build the server

~~~
bundle install
~~~

2. Run the server

~~~
ruby server.rb -o 0.0.0.0
~~~

3. Go to [http://localhost:4242/onramp.html](http://localhost:4242/onramp.html)