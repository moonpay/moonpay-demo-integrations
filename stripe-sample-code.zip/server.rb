require 'sinatra'
require 'stripe'
# This is your test secret API key.
# Don't put any keys in code. See https://docs.stripe.com/keys-best-practices.
client = Stripe::StripeClient.new('sk_test_51TTHmmQZx3micfpjQGsxWDwebKl7xBqqgvuCa6cNxC9iXZfPgxCfcI7JzVR0SKbzJWhegK8vAHXhWOcROwjImEQ0009VhL6sCc')

set :static, true
set :port, 4242

# An endpoint to create a new onramp session
post '/create-onramp-session' do
  content_type 'application/json'
  data = JSON.parse(request.body.read)

  # Create an OnrampSession with amount and currency
  response = client.raw_request(
    :post,
    '/v1/crypto/onramp_sessions',
    params: {
      transaction_details: {
        destination_currency: data['transaction_details']['destination_currency'],
        destination_exchange_amount: data['transaction_details']['destination_exchange_amount'],
        destination_network: data['transaction_details']['destination_network']
      },
      customer_ip_address: request.ip
    }
  )
  onramp_session = response.data

  {
    clientSecret: onramp_session[:client_secret]
  }.to_json
end